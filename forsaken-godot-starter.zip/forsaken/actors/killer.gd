class_name Killer
extends Actor

var data := {}
var target: Survivor = null
var atk_cd := 0.0
var ab_cd := 0.0
var ability_t := 0.0
var sense_t := 0.0
var chase_t := 0.0
var inv_t := 0.0
var investigate := Vector3.ZERO
var last_seen := Vector3.ZERO
var patrol_pt := Vector3.ZERO


func configure(c: Color, player: bool, d: Dictionary) -> void:
	color = c
	is_player = player
	data = d
	base_speed = d.speed


func _post_ready() -> void:
	var l := OmniLight3D.new()
	l.light_color = Color(1, 0.1, 0.05)
	l.light_energy = 1.2
	l.omni_range = 9.0
	l.position.y = 1.5
	add_child(l)


func use_ability() -> void:
	if ab_cd > 0.0:
		return
	ab_cd = data.cd
	if data.ability == "dash":
		ability_t = 1.0
	elif data.ability == "sense":
		sense_t = 6.0
	Sfx.play_at("roar", self)


func try_attack() -> void:
	if atk_cd > 0.0:
		return
	atk_cd = 1.0
	var fwd := -global_transform.basis.z
	for s in game.survivors:
		if s.escaped or s.dead or s.hurt_t > 0.0:
			continue
		if s.downed and s.down_t < 8.0:
			continue
		var to: Vector3 = s.global_position - global_position
		to.y = 0.0
		var d := to.length()
		if d < 2.0 and (d < 0.8 or fwd.dot(to.normalized()) > 0.2):
			s.take_hit()
			Sfx.play_at("hit", self)
			break


func think(delta: float) -> void:
	atk_cd = maxf(0.0, atk_cd - delta)
	ab_cd = maxf(0.0, ab_cd - delta)
	ability_t = maxf(0.0, ability_t - delta)
	sense_t = maxf(0.0, sense_t - delta)
	speed_mult = 1.0
	if is_player:
		dir = player_dir()
		if game.held("action"):
			try_attack()
		if game.held("ability"):
			use_ability()
	else:
		_ai_think(delta)
	if ability_t > 0.0 and data.ability == "dash":
		speed_mult = 2.6
		dir = -global_transform.basis.z
		dir.y = 0.0


func _ai_think(delta: float) -> void:
	var seen: Survivor = null
	var sd := 9999.0
	var heard := Vector3.INF
	var fwd := -global_transform.basis.z
	for s in game.survivors:
		if not s.targetable():
			continue
		var to: Vector3 = s.global_position - global_position
		to.y = 0.0
		var d := to.length()
		var vr := 16.0
		if s.crouching:
			vr = 8.0
		if s.is_hidden:
			vr = 1.8
		if sense_t > 0.0:
			vr = 80.0
		var cone: bool = d < 3.0 or fwd.dot(to.normalized()) > 0.3 or sense_t > 0.0
		if d < vr and cone and (sense_t > 0.0 or game.los(global_position, s.global_position)) and d < sd:
			seen = s
			sd = d
		elif (s.sprinting and d < 18.0) or (s.repairing and d < 12.0):
			heard = s.global_position
	if seen != null:
		target = seen
		last_seen = seen.global_position
		chase_t = 5.0
	else:
		chase_t = maxf(0.0, chase_t - delta)
		if chase_t <= 0.0:
			target = null
			if heard != Vector3.INF:
				investigate = heard
				inv_t = 6.0
	if target != null:
		var goal: Vector3 = seen.global_position if seen != null else last_seen
		dir = nav_dir(goal)
		if seen != null and sd < 1.9:
			try_attack()
		if ab_cd <= 0.0:
			if data.ability == "dash" and seen != null and sd > 4.0 and sd < 12.0:
				use_ability()
			elif data.ability == "sense" and seen == null:
				use_ability()
	elif inv_t > 0.0:
		inv_t -= delta
		dir = nav_dir(investigate)
		if global_position.distance_to(investigate) < 2.5:
			inv_t = 0.0
	else:
		if patrol_pt == Vector3.ZERO or global_position.distance_to(patrol_pt) < 2.5:
			patrol_pt = game.random_point()
		dir = nav_dir(patrol_pt)
		if data.ability == "sense" and ab_cd <= 0.0 and randf() < 0.01:
			use_ability()
