class_name Survivor
extends Actor

var data := {}
var max_stamina := 100.0
var stamina := 100.0
var exhausted := false
var hp := 2            # 2 healthy, 1 injured
var downed := false
var dead := false
var escaped := false
var crouching := false
var sprinting := false
var repairing := false
var is_hidden := false
var down_t := 0.0
var revive_t := 0.0
var hurt_t := 0.0
var ab_cd := 0.0
var burst_t := 0.0


func configure(c: Color, player: bool, d: Dictionary) -> void:
	color = c
	is_player = player
	data = d
	base_speed = d.speed
	max_stamina = d.stamina
	stamina = max_stamina


func active() -> bool:
	return not dead and not escaped and not downed


func targetable() -> bool:
	return not dead and not escaped and (not downed or down_t > 8.0)


func take_hit() -> void:
	if downed:
		eliminate()
		return
	hurt_t = 1.5
	hp -= 1
	if hp <= 0:
		hp = 0
		downed = true
		down_t = 0.0
		revive_t = 0.0
		body_mesh.rotation.x = deg_to_rad(-80.0)
		body_mesh.position.y = 0.4


func revive() -> void:
	downed = false
	hp = 1
	revive_t = 0.0
	hurt_t = 2.0
	body_mesh.rotation.x = 0.0
	body_mesh.position.y = 0.9


func eliminate() -> void:
	dead = true
	downed = false
	visible = false


func escape() -> void:
	escaped = true
	visible = false


func use_ability() -> void:
	if ab_cd > 0.0 or data.ability == "none":
		return
	ab_cd = data.cd
	if data.ability == "burst":
		burst_t = 2.5
	elif data.ability == "heal":
		for s in game.survivors:
			if not s.dead and not s.escaped and s.global_position.distance_to(global_position) < 5.0:
				if s.downed:
					s.revive()
				elif s.hp < 2:
					s.hp = 2
		Sfx.play_at("heal", self)


func think(delta: float) -> void:
	hurt_t = maxf(0.0, hurt_t - delta)
	ab_cd = maxf(0.0, ab_cd - delta)
	burst_t = maxf(0.0, burst_t - delta)
	repairing = false
	sprinting = false
	crouching = false
	if dead or escaped:
		dir = Vector3.ZERO
		return
	if downed:
		dir = Vector3.ZERO
		down_t += delta
		if down_t > 30.0:
			eliminate()
		return
	if is_player:
		_player_think()
	else:
		_bot_think(delta)
	is_hidden = crouching and game.in_hide(global_position)
	if not is_player:
		body_mesh.visible = not is_hidden
	var moving := dir.length() > 0.1
	var m := 1.0
	if crouching:
		m = 0.5
	elif sprinting and moving and stamina > 0.0 and not exhausted:
		m = 1.6
		stamina -= 25.0 * delta
		if stamina <= 0.0:
			stamina = 0.0
			exhausted = true
	else:
		sprinting = false
		stamina = minf(max_stamina, stamina + (10.0 if moving else 18.0) * delta)
		if exhausted and stamina > 25.0:
			exhausted = false
	if hp == 1:
		m *= 0.92
	if burst_t > 0.0:
		m *= 1.5
	speed_mult = m
	var sensed: bool = game.killer.sense_t > 0.0
	mat.emission_enabled = sensed
	mat.emission = Color(1, 0.1, 0.1)
	mat.no_depth_test = sensed
	mat.albedo_color = color.lerp(Color(0.6, 0, 0), 0.4) if hp == 1 else color
	_interact(delta)
	if game.exit_open and global_position.distance_to(game.exit_pos) < 2.5:
		escape()


func _target_downed() -> Survivor:
	return game.nearest_downed(self, 2.2)


func _can_interact() -> bool:
	return _target_downed() != null or game.nearest_gen(global_position, 2.5) != null


func _interact(delta: float) -> void:
	if not repairing:
		return
	var d: Survivor = _target_downed()
	if d != null:
		d.revive_t += delta
		if d.revive_t >= 4.0:
			d.revive()
		return
	var g: Generator = game.nearest_gen(global_position, 2.5)
	if g != null:
		g.add_progress(delta * float(data.repair))


func _player_think() -> void:
	dir = player_dir()
	crouching = game.held("crouch")
	sprinting = game.held("sprint") and not crouching
	repairing = game.held("action")
	if game.held("ability"):
		use_ability()
	if repairing and _can_interact():
		dir = Vector3.ZERO


func _bot_think(_delta: float) -> void:
	var k: Killer = game.killer
	var kd := global_position.distance_to(k.global_position)
	var seen: bool = kd < 18.0 and game.los(global_position, k.global_position)
	if ab_cd <= 0.0:
		if data.ability == "burst" and kd < 8.0:
			use_ability()
		elif data.ability == "heal" and kd > 14.0 and (hp < 2 or game.any_injured_near(self, 5.0)):
			use_ability()
	if kd < 10.0 or seen:
		var hs: Vector3 = game.nearest_hide(global_position)
		var hd := global_position.distance_to(hs)
		if hd < 1.2:
			crouching = true
			dir = Vector3.ZERO
		elif hd < 14.0 and hd < kd:
			dir = nav_dir(hs)
			sprinting = kd < 10.0
		else:
			var away := global_position - k.global_position
			away.y = 0.0
			var goal := global_position + away.normalized() * 12.0
			goal.x = clampf(goal.x, -game.half + 3.0, game.half - 3.0)
			goal.z = clampf(goal.z, -game.half + 3.0, game.half - 3.0)
			dir = nav_dir(goal)
			sprinting = true
		return
	if kd > 16.0:
		var dn: Survivor = game.nearest_downed(self, 45.0)
		if dn != null:
			if global_position.distance_to(dn.global_position) < 1.8:
				repairing = true
				dir = Vector3.ZERO
			else:
				dir = nav_dir(dn.global_position)
			return
	if game.exit_open:
		dir = nav_dir(game.exit_pos)
		return
	var g: Generator = game.nearest_gen(global_position, 999.0)
	if g == null:
		dir = Vector3.ZERO
	elif global_position.distance_to(g.global_position) < 1.8:
		repairing = true
		dir = Vector3.ZERO
	else:
		dir = nav_dir(g.global_position)
