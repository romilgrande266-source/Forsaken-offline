class_name TouchControls
extends CanvasLayer
# Multi-touch on-screen controls: floating stick on the left, buttons on the right.
# Dragging on the right side of the screen looks around (handled in Actor).

var state := {"sprint": false, "crouch": false, "action": false, "ability": false}
var move := Vector2.ZERO
var pad: Control
var _fingers := {}
var _origin := Vector2.ZERO
var _stick := Vector2.ZERO


func _ready() -> void:
	pad = Control.new()
	pad.set_anchors_preset(Control.PRESET_FULL_RECT)
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(pad)
	pad.draw.connect(_draw_ui)


func _buttons() -> Dictionary:
	var s := get_viewport().get_visible_rect().size
	return {
		"action": [Vector2(s.x - 110, s.y - 110), 70.0, "ACT"],
		"ability": [Vector2(s.x - 260, s.y - 80), 48.0, "Q"],
		"sprint": [Vector2(s.x - 90, s.y - 270), 52.0, "RUN"],
		"crouch": [Vector2(s.x - 240, s.y - 200), 48.0, "HIDE"],
	}


func _hit(p: Vector2) -> String:
	var b := _buttons()
	for k in b.keys():
		if p.distance_to(b[k][0]) <= b[k][1] * 1.2:
			return k
	return ""


func _input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		if e.pressed:
			var hit := _hit(e.position)
			if hit != "":
				_fingers[e.index] = hit
				state[hit] = true
			elif e.position.x < get_viewport().get_visible_rect().size.x * 0.4:
				_fingers[e.index] = "stick"
				_origin = e.position
				_stick = e.position
		elif _fingers.has(e.index):
			var k: String = _fingers[e.index]
			if k == "stick":
				move = Vector2.ZERO
			else:
				state[k] = false
			_fingers.erase(e.index)
		pad.queue_redraw()
	elif e is InputEventScreenDrag and _fingers.get(e.index, "") == "stick":
		_stick = e.position
		move = ((e.position - _origin) / 90.0).limit_length(1.0)
		pad.queue_redraw()


func _draw_ui() -> void:
	var f := ThemeDB.fallback_font
	var b := _buttons()
	for k in b.keys():
		var c: Vector2 = b[k][0]
		var r: float = b[k][1]
		pad.draw_circle(c, r, Color(1, 1, 1, 0.38 if state[k] else 0.16))
		pad.draw_string(f, c + Vector2(-r * 0.6, 8), b[k][2], HORIZONTAL_ALIGNMENT_CENTER, r * 1.2, 20)
	if _fingers.values().has("stick"):
		pad.draw_circle(_origin, 80.0, Color(1, 1, 1, 0.12))
		pad.draw_circle(_origin + (_stick - _origin).limit_length(80.0), 34.0, Color(1, 1, 1, 0.35))
