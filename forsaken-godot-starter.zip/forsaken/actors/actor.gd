class_name Actor
extends CharacterBody3D
# Shared base for survivors and killers. Player and AI use the same body;
# subclasses fill `dir` and flags in think().

var is_player := false
var color := Color.WHITE
var base_speed := 5.0
var speed_mult := 1.0
var dir := Vector3.ZERO
var yaw := 0.0
var pitch := -0.2
var game
var body_mesh: MeshInstance3D
var mat: StandardMaterial3D
var pivot: Node3D
var agent: NavigationAgent3D
var steps: AudioStreamPlayer3D
var _step_t := 0.0
var _nav_t := 0.0
var _nav_goal := Vector3.INF


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	var cm := CapsuleMesh.new()
	cm.radius = 0.4
	cm.height = 1.8
	mat = StandardMaterial3D.new()
	mat.albedo_color = color
	cm.material = mat
	body_mesh = MeshInstance3D.new()
	body_mesh.mesh = cm
	body_mesh.position.y = 0.9
	add_child(body_mesh)
	agent = NavigationAgent3D.new()
	agent.path_desired_distance = 0.8
	agent.target_desired_distance = 1.0
	add_child(agent)
	steps = AudioStreamPlayer3D.new()
	steps.stream = Sfx.get_stream("step")
	steps.unit_size = 6.0
	add_child(steps)
	if is_player:
		pivot = Node3D.new()
		pivot.position.y = 1.6
		add_child(pivot)
		var cam := Camera3D.new()
		cam.position = Vector3(0, 0.6, 3.5)
		pivot.add_child(cam)
		cam.make_current()
		var fl := SpotLight3D.new()
		fl.spot_range = 22.0
		fl.spot_angle = 38.0
		fl.light_energy = 3.0
		pivot.add_child(fl)
	_post_ready()


func _post_ready() -> void:
	pass


func think(_delta: float) -> void:
	pass


func _physics_process(delta: float) -> void:
	if game == null or game.ended:
		return
	think(delta)
	var spd := base_speed * speed_mult
	var h := Vector3(dir.x, 0.0, dir.z)
	velocity.x = h.x * spd
	velocity.z = h.z * spd
	if is_on_floor():
		velocity.y = -0.1
	else:
		velocity.y -= 20.0 * delta
	move_and_slide()
	if is_player:
		rotation.y = yaw
		pivot.rotation.x = pitch
	elif h.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-h.x, -h.z), 8.0 * delta)
	if h.length() > 0.1 and speed_mult > 0.6 and is_on_floor():
		_step_t -= delta
		if _step_t <= 0.0:
			_step_t = 2.2 / maxf(spd, 1.0)
			steps.pitch_scale = randf_range(0.8, 1.2)
			steps.play()


func _unhandled_input(event: InputEvent) -> void:
	if not is_player:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * 0.003
		pitch = clampf(pitch - event.relative.y * 0.003, -1.0, 0.6)
	elif event is InputEventScreenDrag and event.position.x > get_viewport().get_visible_rect().size.x * 0.4:
		yaw -= event.relative.x * 0.006
		pitch = clampf(pitch - event.relative.y * 0.006, -1.0, 0.6)


func player_dir() -> Vector3:
	var v := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if game.touch != null and game.touch.move.length() > 0.1:
		v = game.touch.move
	return Basis(Vector3.UP, yaw) * Vector3(v.x, 0.0, v.y)


func nav_dir(to: Vector3) -> Vector3:
	_nav_t -= get_physics_process_delta_time()
	if _nav_t <= 0.0 or _nav_goal.distance_to(to) > 3.0:
		_nav_t = 0.3
		_nav_goal = to
		agent.target_position = to
	var n := agent.get_next_path_position()
	var d := n - global_position
	d.y = 0.0
	return d.normalized() if d.length() > 0.15 else Vector3.ZERO
