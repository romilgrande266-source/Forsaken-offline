class_name Match
extends Node3D
# Builds the whole match in code: map, nav mesh, actors, HUD, audio.

const GEN_SPOTS := [Vector3(-22, 0, -22), Vector3(-22, 0, 0), Vector3(0, 0, -20), Vector3(26, 0, -20),
	Vector3(-5, 0, 20), Vector3(10, 0, 22), Vector3(26, 0, 22)]
const HIDE_SPOTS := [Vector3(-8, 0, -14), Vector3(8, 0, -14), Vector3(-16, 0, 14), Vector3(8, 0, 16),
	Vector3(24, 0, 4), Vector3(-24, 0, -8), Vector3(16, 0, -24), Vector3(-4, 0, -4)]
# [x, z, width, depth]
const WALLS := [[-18, -10, 24, 1], [24, -10, 12, 1], [-22, 10, 16, 1], [14, 10, 32, 1],
	[-10, -24, 1, 12], [-10, 2, 1, 16], [12, -20, 1, 18], [20, 22, 1, 12]]
const CRATES := [[-3, -3], [5, 4], [-6, 5], [8, -5], [0, 14], [-16, -16], [18, 16]]
const HINT := "Hold E / ACT: repair gens, revive.  Crouch inside a hiding spot to vanish.  Q: ability."

var half := 30.0
var survivors: Array = []
var killer: Killer
var player: Actor
var generators: Array = []
var hide_spots: Array = []
var exit_pos := Vector3(-26, 0, 26)
var exit_open := false
var exit_mat: StandardMaterial3D
var touch: TouchControls = null
var ended := false
var elapsed := 0.0
var rng := RandomNumberGenerator.new()
var region: NavigationRegion3D
var hud_gen: Label
var hud_hp: Label
var hud_cd: Label
var hud_msg: Label
var hud_stam: ProgressBar
var pause_ui: CanvasLayer = null
var chase_player: AudioStreamPlayer


func _ready() -> void:
	rng.randomize()
	var m: Dictionary = GameState.maps[GameState.map_idx]
	_build_env(m)
	_build_world(m)
	_spawn()
	_build_hud()
	_build_audio()
	GameState.apply_settings()
	if not GameState.is_mobile():
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


# ---------- world ----------

func _build_env(m: Dictionary) -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = m.fog
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.25, 0.28, 0.36)
	env.ambient_light_energy = m.light
	env.fog_enabled = true
	env.fog_light_color = m.fog
	env.fog_density = 0.04
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.light_energy = m.light * 0.5
	sun.rotation_degrees = Vector3(-60, 30, 0)
	sun.shadow_enabled = GameState.quality >= 1
	add_child(sun)


func _box(parent: Node, pos: Vector3, sz: Vector3, col: Color, solid := true) -> Node3D:
	var b: Node3D = StaticBody3D.new() if solid else Node3D.new()
	b.position = pos
	if solid:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = sz
		cs.shape = sh
		b.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = sz
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	bm.material = mt
	mi.mesh = bm
	b.add_child(mi)
	parent.add_child(b)
	return b


func _build_world(m: Dictionary) -> void:
	region = NavigationRegion3D.new()
	var nm := NavigationMesh.new()
	nm.agent_radius = 0.5
	nm.agent_height = 1.8
	region.navigation_mesh = nm
	add_child(region)
	_box(region, Vector3(0, -0.5, 0), Vector3(half * 2, 1, half * 2), Color(0.15, 0.15, 0.16))
	var wc := Color(0.28, 0.28, 0.3)
	_box(region, Vector3(0, 2, -half), Vector3(half * 2, 4, 1), wc)
	_box(region, Vector3(0, 2, half), Vector3(half * 2, 4, 1), wc)
	_box(region, Vector3(-half, 2, 0), Vector3(1, 4, half * 2), wc)
	_box(region, Vector3(half, 2, 0), Vector3(1, 4, half * 2), wc)
	# pick 3 generators
	var spots := GEN_SPOTS.duplicate()
	for i in 3:
		var idx := rng.randi() % spots.size()
		var g := Generator.new()
		g.position = spots[idx]
		spots.remove_at(idx)
		add_child(g)
		generators.append(g)
	if m.kind == "walls":
		for w in WALLS:
			_box(region, Vector3(w[0], 1.75, w[1]), Vector3(w[2], 3.5, w[3]), Color(0.32, 0.3, 0.28))
		for c in CRATES:
			_box(region, Vector3(c[0], 0.75, c[1]), Vector3(2, 1.5, 2), Color(0.35, 0.25, 0.15))
	else:
		for i in 90:
			var p := Vector3(rng.randf_range(-half + 2, half - 2), 0, rng.randf_range(-half + 2, half - 2))
			if p.length() < 6.0 or _near_poi(p, 3.0):
				continue
			var tb := StaticBody3D.new()
			tb.position = p + Vector3(0, 3, 0)
			var cs := CollisionShape3D.new()
			var sh := CylinderShape3D.new()
			sh.radius = 0.5
			sh.height = 6.0
			cs.shape = sh
			tb.add_child(cs)
			var mi := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.4
			cm.bottom_radius = 0.5
			cm.height = 6.0
			var mt := StandardMaterial3D.new()
			mt.albedo_color = Color(0.2, 0.12, 0.07)
			cm.material = mt
			mi.mesh = cm
			tb.add_child(mi)
			region.add_child(tb)
	for h in HIDE_SPOTS:
		var col := Color(0.12, 0.18, 0.12) if m.kind == "walls" else Color(0.08, 0.3, 0.1)
		_box(self, h + Vector3(0, 0.9, 0), Vector3(1.0, 1.8, 1.0), col, false)
		hide_spots.append(h)
	var ex := _box(self, exit_pos + Vector3(0, 3, 0), Vector3(1.2, 6, 1.2), Color(0.8, 0.1, 0.1), false)
	exit_mat = (ex.get_child(0) as MeshInstance3D).mesh.material
	exit_mat.emission_enabled = true
	region.bake_navigation_mesh(false)


func _near_poi(p: Vector3, r: float) -> bool:
	for s in GEN_SPOTS:
		if p.distance_to(s) < r:
			return true
	return p.distance_to(exit_pos) < r or p.distance_to(Vector3(26, 0, -26)) < r


func _spawn() -> void:
	var is_surv: bool = GameState.role == "survivor"
	var cols := [Color(0.2, 0.6, 1.0), Color(0.3, 0.9, 0.4), Color(1.0, 0.8, 0.2), Color(0.9, 0.4, 0.9)]
	var spawns := [Vector3(-4, 0.1, 2), Vector3(-1, 0.1, 4), Vector3(2, 0.1, 2), Vector3(5, 0.1, 4)]
	for i in 4:
		var s := Survivor.new()
		var d: Dictionary = GameState.survivors[GameState.survivor_idx] if (i == 0 and is_surv) \
			else GameState.survivors[rng.randi() % GameState.survivors.size()]
		s.configure(cols[i], i == 0 and is_surv, d)
		s.game = self
		s.position = spawns[i]
		add_child(s)
		survivors.append(s)
		if s.is_player:
			player = s
	killer = Killer.new()
	killer.configure(Color(0.55, 0.05, 0.05), not is_surv, GameState.killers[GameState.killer_idx])
	killer.game = self
	killer.position = Vector3(26, 0.1, -26)
	add_child(killer)
	if not is_surv:
		player = killer


# ---------- queries used by actors ----------

func held(action: String) -> bool:
	return Input.is_action_pressed(action) or (touch != null and touch.state.get(action, false))


func los(a: Vector3, b: Vector3) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a + Vector3.UP * 1.4, b + Vector3.UP * 1.4, 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func in_hide(p: Vector3) -> bool:
	for h in hide_spots:
		if p.distance_to(h) < 1.6:
			return true
	return false


func nearest_hide(p: Vector3) -> Vector3:
	var best: Vector3 = hide_spots[0]
	for h in hide_spots:
		if p.distance_to(h) < p.distance_to(best):
			best = h
	return best


func nearest_gen(p: Vector3, r: float) -> Generator:
	var best: Generator = null
	var bd := r
	for g in generators:
		if g.done:
			continue
		var d := p.distance_to(g.global_position)
		if d < bd:
			bd = d
			best = g
	return best


func nearest_downed(from: Survivor, r: float) -> Survivor:
	var best: Survivor = null
	var bd := r
	for s in survivors:
		if s == from or not s.downed or s.dead or s.escaped:
			continue
		var d := from.global_position.distance_to(s.global_position)
		if d < bd:
			bd = d
			best = s
	return best


func any_injured_near(from: Survivor, r: float) -> bool:
	for s in survivors:
		if s != from and s.active() and s.hp < 2 and from.global_position.distance_to(s.global_position) < r:
			return true
	return false


func gens_done() -> int:
	var n := 0
	for g in generators:
		if g.done:
			n += 1
	return n


func random_point() -> Vector3:
	var p := NavigationServer3D.map_get_random_point(get_world_3d().navigation_map, 1, true)
	return p if p != Vector3.ZERO else Vector3(rng.randf_range(-20, 20), 0, rng.randf_range(-20, 20))


# ---------- HUD / UI ----------

func _theme() -> Theme:
	var th := Theme.new()
	th.default_font_size = 22
	return th


func _build_hud() -> void:
	var cl := CanvasLayer.new()
	add_child(cl)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _theme()
	cl.add_child(root)
	var vb := VBoxContainer.new()
	vb.position = Vector2(20, 14)
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vb)
	hud_gen = Label.new()
	hud_hp = Label.new()
	hud_cd = Label.new()
	hud_stam = ProgressBar.new()
	hud_stam.custom_minimum_size = Vector2(220, 16)
	hud_stam.show_percentage = false
	for n in [hud_gen, hud_hp, hud_stam, hud_cd]:
		vb.add_child(n)
	hud_msg = Label.new()
	hud_msg.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hud_msg.offset_left = -450
	hud_msg.offset_right = 450
	hud_msg.offset_top = 70
	hud_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(hud_msg)
	var pb := Button.new()
	pb.text = "II"
	pb.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pb.offset_left = -84
	pb.offset_right = -16
	pb.offset_top = 16
	pb.offset_bottom = 64
	pb.pressed.connect(_toggle_pause)
	root.add_child(pb)
	if GameState.is_mobile():
		touch = TouchControls.new()
		add_child(touch)


func _hud() -> void:
	hud_gen.text = "Generators %d/%d   Exit: %s" % [gens_done(), generators.size(), "OPEN" if exit_open else "locked"]
	hud_msg.text = HINT if elapsed < 12.0 else ""
	hud_stam.value = 100.0
	if player is Survivor:
		var p: Survivor = player
		hud_hp.text = ("DOWNED - bleeding out %ds" % int(30.0 - p.down_t)) if p.downed \
			else ("Injured" if p.hp == 1 else "Healthy")
		hud_stam.value = p.stamina / p.max_stamina * 100.0
		hud_cd.text = "Ability: passive" if p.data.ability == "none" \
			else ("Ability: READY" if p.ab_cd <= 0.0 else "Ability: %ds" % ceili(p.ab_cd))
	else:
		var k: Killer = killer
		hud_hp.text = "Killer: " + str(k.data.name)
		hud_cd.text = "Ability: READY" if k.ab_cd <= 0.0 else "Ability: %ds" % ceili(k.ab_cd)


func _panel(title: String, items: Array) -> CanvasLayer:
	var cl := CanvasLayer.new()
	cl.layer = 10
	cl.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(cl)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.theme = _theme()
	cl.add_child(dim)
	var cc := CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.add_child(cc)
	var vb := VBoxContainer.new()
	cc.add_child(vb)
	var t := Label.new()
	t.text = title
	t.add_theme_font_size_override("font_size", 40)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	for it in items:
		var bt := Button.new()
		bt.text = it[0]
		bt.custom_minimum_size = Vector2(320, 52)
		bt.pressed.connect(it[1])
		vb.add_child(bt)
	return cl


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and not ended:
		_toggle_pause()


func _toggle_pause() -> void:
	if ended:
		return
	if pause_ui != null:
		_resume()
		return
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	pause_ui = _panel("PAUSED", [["Resume", _resume], ["Main menu", _to_menu]])


func _resume() -> void:
	get_tree().paused = false
	if pause_ui != null:
		pause_ui.queue_free()
		pause_ui = null
	if not GameState.is_mobile():
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _to_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://ui/main_menu.tscn")


func _again() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


# ---------- audio, loop, end ----------

func _build_audio() -> void:
	var amb := AudioStreamPlayer.new()
	amb.stream = Sfx.get_stream("ambient")
	amb.volume_db = -14.0
	add_child(amb)
	amb.play()
	chase_player = AudioStreamPlayer.new()
	chase_player.stream = Sfx.get_stream("chase")
	chase_player.volume_db = -60.0
	add_child(chase_player)
	chase_player.play()


func _music(delta: float) -> void:
	var near := false
	if player is Survivor:
		near = player.global_position.distance_to(killer.global_position) < 16.0
	else:
		for s in survivors:
			if s.active() and s.global_position.distance_to(killer.global_position) < 14.0:
				near = true
	chase_player.volume_db = lerpf(chase_player.volume_db, -8.0 if near else -60.0, 3.0 * delta)


func _process(delta: float) -> void:
	if ended:
		return
	elapsed += delta
	exit_open = gens_done() >= generators.size()
	exit_mat.albedo_color = Color(0.1, 1.0, 0.3) if exit_open else Color(0.8, 0.1, 0.1)
	exit_mat.emission = exit_mat.albedo_color
	_hud()
	_music(delta)
	_check_end()


func _check_end() -> void:
	var left := 0
	var dead := 0
	for s in survivors:
		if s.dead:
			dead += 1
		elif not s.escaped:
			left += 1
	if player is Survivor:
		var p: Survivor = player
		if p.escaped:
			_end(true, "YOU ESCAPED")
		elif p.dead:
			_end(false, "YOU DIED")
	elif left == 0:
		_end(dead >= 2, "YOU WIN - %d eliminated" % dead if dead >= 2 else "TOO MANY ESCAPED")


func _end(win: bool, text: String) -> void:
	ended = true
	var st: Dictionary = GameState.stats
	st["matches"] += 1
	if win:
		st["wins"] += 1
	if player is Survivor and (player as Survivor).escaped:
		st["escapes"] += 1
	if not (player is Survivor):
		for s in survivors:
			if s.dead:
				st["kills"] += 1
	GameState.save_data()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_panel(text, [["Play again", _again], ["Main menu", _to_menu]])
