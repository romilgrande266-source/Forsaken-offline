extends Node

const SAVE := "user://save.json"

var survivors := [
	{"name": "Runner", "speed": 5.0, "stamina": 130.0, "repair": 1.0, "ability": "burst", "cd": 20.0, "desc": "Fast and enduring.\nAbility: speed burst."},
	{"name": "Medic", "speed": 4.6, "stamina": 100.0, "repair": 1.0, "ability": "heal", "cd": 25.0, "desc": "Heals and revives nearby allies.\nAbility: heal pulse."},
	{"name": "Engineer", "speed": 4.5, "stamina": 100.0, "repair": 1.6, "ability": "none", "cd": 0.0, "desc": "Repairs generators 60% faster.\nPassive only."},
]
var killers := [
	{"name": "Brute", "speed": 4.4, "ability": "dash", "cd": 12.0, "desc": "Strong and relentless.\nAbility: lunge dash."},
	{"name": "Stalker", "speed": 4.8, "ability": "sense", "cd": 25.0, "desc": "Fast hunter.\nAbility: reveals survivors for 6s."},
]
var maps := [
	{"name": "Abandoned Facility", "kind": "walls", "fog": Color(0.04, 0.05, 0.07), "light": 0.5},
	{"name": "Dark Forest", "kind": "trees", "fog": Color(0.02, 0.06, 0.03), "light": 0.4},
]
var qualities := ["Low", "Medium", "High"]

var survivor_idx := 0
var killer_idx := 0
var map_idx := 0
var role := "survivor"
var quality := 1
var fps := 60
var volume := 0.8
var stats := {"matches": 0, "wins": 0, "escapes": 0, "kills": 0}


func _ready() -> void:
	_key("move_forward", KEY_W)
	_key("move_back", KEY_S)
	_key("move_left", KEY_A)
	_key("move_right", KEY_D)
	_key("sprint", KEY_SHIFT)
	_key("crouch", KEY_C)
	_key("action", KEY_E)
	_key("ability", KEY_Q)
	_key("pause", KEY_ESCAPE)
	var mb := InputEventMouseButton.new()
	mb.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("action", mb)
	load_data()
	apply_settings()


func _key(action: String, key: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var e := InputEventKey.new()
	e.physical_keycode = key
	InputMap.action_add_event(action, e)


func is_mobile() -> bool:
	return OS.has_feature("mobile") or DisplayServer.is_touchscreen_available()


func apply_settings() -> void:
	Engine.max_fps = fps
	var scales := [0.6, 0.8, 1.0]
	get_tree().root.scaling_3d_scale = scales[quality]
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.001)))


func save_data() -> void:
	var f := FileAccess.open(SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({"stats": stats, "survivor": survivor_idx, "killer": killer_idx,
			"map": map_idx, "role": role, "quality": quality, "fps": fps, "volume": volume}))


func load_data() -> void:
	if not FileAccess.file_exists(SAVE):
		return
	var f := FileAccess.open(SAVE, FileAccess.READ)
	if f == null:
		return
	var d = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return
	var st: Dictionary = d.get("stats", {})
	for k in stats.keys():
		stats[k] = int(st.get(k, 0))
	survivor_idx = clampi(int(d.get("survivor", 0)), 0, survivors.size() - 1)
	killer_idx = clampi(int(d.get("killer", 0)), 0, killers.size() - 1)
	map_idx = clampi(int(d.get("map", 0)), 0, maps.size() - 1)
	role = str(d.get("role", "survivor"))
	quality = clampi(int(d.get("quality", 1)), 0, 2)
	fps = int(d.get("fps", 60))
	volume = float(d.get("volume", 0.8))
