extends Control

var btns := {}
var desc: Label
var stats_l: Label
var status: Label


func _ready() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var th := Theme.new()
	th.default_font_size = 22
	theme = th
	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.03, 0.05)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var mc := MarginContainer.new()
	mc.set_anchors_preset(Control.PRESET_FULL_RECT)
	for s in ["left", "right", "top", "bottom"]:
		mc.add_theme_constant_override("margin_" + s, 32)
	add_child(mc)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 40)
	mc.add_child(row)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(left)
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(right)
	var title := Label.new()
	title.text = "FORSAKEN"
	title.add_theme_font_size_override("font_size", 64)
	title.add_theme_color_override("font_color", Color(0.8, 0.1, 0.1))
	left.add_child(title)
	var sub := Label.new()
	sub.text = "Offline mode - single player vs AI bots"
	left.add_child(sub)
	desc = Label.new()
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size.y = 120
	left.add_child(desc)
	stats_l = Label.new()
	left.add_child(stats_l)
	status = Label.new()
	left.add_child(status)
	for k in ["role", "surv", "kill", "map", "quality", "fps", "volume", "play", "quit"]:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 46)
		b.pressed.connect(_on.bind(k))
		right.add_child(b)
		btns[k] = b
	_refresh()


func _on(k: String) -> void:
	var g := GameState
	match k:
		"role": g.role = "killer" if g.role == "survivor" else "survivor"
		"surv": g.survivor_idx = (g.survivor_idx + 1) % g.survivors.size()
		"kill": g.killer_idx = (g.killer_idx + 1) % g.killers.size()
		"map": g.map_idx = (g.map_idx + 1) % g.maps.size()
		"quality": g.quality = (g.quality + 1) % 3
		"fps": g.fps = 30 if g.fps == 60 else 60
		"volume": g.volume = snappedf(fmod(g.volume + 0.2, 1.2), 0.1)
		"play":
			_play()
			return
		"quit":
			get_tree().quit()
			return
	g.apply_settings()
	g.save_data()
	_refresh()


func _refresh() -> void:
	var g := GameState
	btns.role.text = "Play as: " + g.role.capitalize()
	btns.surv.text = "Survivor: " + g.survivors[g.survivor_idx].name
	btns.kill.text = "Killer: " + g.killers[g.killer_idx].name
	btns.map.text = "Map: " + g.maps[g.map_idx].name
	btns.quality.text = "Graphics: " + g.qualities[g.quality]
	btns.fps.text = "FPS cap: %d" % g.fps
	btns.volume.text = "Volume: %d%%" % int(g.volume * 100.0)
	btns.play.text = "PLAY (vs bots)"
	btns.quit.text = "Quit"
	var c: Dictionary = g.survivors[g.survivor_idx] if g.role == "survivor" else g.killers[g.killer_idx]
	var stat_line := "Speed %.1f" % c.speed
	if g.role == "survivor":
		stat_line += "  Stamina %d  Repair x%.1f" % [int(c.stamina), c.repair]
	desc.text = "%s\n%s\n%s" % [c.name, stat_line, c.desc]
	stats_l.text = "Matches %d | Wins %d | Escapes %d | Kills %d" % [g.stats.matches, g.stats.wins, g.stats.escapes, g.stats.kills]


func _play() -> void:
	for b in btns.values():
		b.disabled = true
	status.text = "Matchmaking: finding bots..."
	await get_tree().create_timer(1.0).timeout
	status.text = "Match found. Loading..."
	await get_tree().create_timer(0.6).timeout
	get_tree().change_scene_to_file("res://maps/match.tscn")
