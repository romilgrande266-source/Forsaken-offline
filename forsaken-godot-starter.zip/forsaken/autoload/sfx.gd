extends Node
# Procedural audio: no asset files needed (fully offline, no licensing).

var streams := {}


func _ready() -> void:
	streams["step"] = _make(80.0, 0.14, 0.9, 0.7, false)
	streams["hit"] = _make(120.0, 0.35, 1.0, 0.5, false)
	streams["roar"] = _make(70.0, 0.7, 1.0, 0.45, false)
	streams["heal"] = _make(520.0, 0.4, 0.5, 0.0, false)
	streams["ambient"] = _make(55.0, 1.0, 0.35, 0.15, true)
	streams["chase"] = _make(110.0, 1.0, 0.5, 0.05, true)


func get_stream(n: String) -> AudioStream:
	return streams[n]


func play_at(n: String, node: Node3D) -> void:
	var p := AudioStreamPlayer3D.new()
	p.stream = streams[n]
	p.unit_size = 10.0
	node.add_child(p)
	p.finished.connect(p.queue_free)
	p.play()


func _make(freq: float, dur: float, vol: float, noise: float, loop: bool) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / rate
		var env := 0.7 + 0.3 * sin(TAU * 2.0 * t) if loop else 1.0 - t / dur
		var s := sin(TAU * freq * t) * (1.0 - noise) + (randf() * 2.0 - 1.0) * noise
		data.encode_s16(i * 2, int(clampf(s * env * vol, -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = n
	return w
