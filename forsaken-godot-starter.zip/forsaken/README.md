# Forsaken Starter (Godot 4.3)

Offline asymmetric horror starter: 4 survivors vs 1 killer, with AI bots.
**Status: UNTESTED.** Written without access to Godot, so expect to fix small
errors on first open. Not a finished game.

## Included
- Menu: role, survivor/killer select, map, graphics quality, FPS cap, volume
- Matchmaking simulation, pause menu, win/lose screen, saved stats (user://save.json)
- Survivors: sprint/stamina, crouch, hide in lockers/bushes, repair 3 generators,
  revive, 3 survivors (Runner, Medic, Engineer) with abilities
- Killers: Brute (dash), Stalker (sense); chase AI, sound reactions, cooldowns
- Survivor bots: repair, flee, hide, revive, escape. Killer bot: patrol, investigate, chase
- Maps: Abandoned Facility, Dark Forest (runtime-baked navmesh)
- Procedural audio (no asset files), touch controls, landscape, GL Compatibility renderer

## Not included (yet)
Haunted School, Hospital, Underground Base maps; LAN multiplayer; skins;
character models/animations (capsules for now); APKs.

## Controls
WASD move, Shift sprint, C crouch, E (or click) action, Q ability, Esc pause.
Touch: left stick, right-side drag to look, ACT/Q/RUN/HIDE buttons.

## Run
Open the folder in Godot 4.3+ and press F5. No internet needed.

## Build Android APKs
1. Editor > Manage Export Templates > install 4.3 templates.
2. Editor Settings > Export > Android: set Android SDK, JDK 17, debug keystore.
3. Project > Export: presets "Android ARM64" and "Android ARMv7" are included.
4. Export each preset. Or push to GitHub and run `.github/workflows/build-android.yml`
   (unverified; may need tweaks).
