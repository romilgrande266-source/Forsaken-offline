class_name Generator
extends Node3D

var progress := 0.0
var done := false
var lbl: Label3D
var mat: StandardMaterial3D


func _ready() -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.4, 1.2, 1.0)
	mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.7, 0.2, 0.1)
	mat.emission_enabled = true
	mat.emission = Color(0.4, 0.05, 0.0)
	bm.material = mat
	mi.mesh = bm
	mi.position.y = 0.6
	add_child(mi)
	lbl = Label3D.new()
	lbl.position.y = 1.9
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.font_size = 48
	add_child(lbl)
	var l := OmniLight3D.new()
	l.light_color = Color(1, 0.4, 0.2)
	l.light_energy = 0.8
	l.omni_range = 6.0
	l.position.y = 1.5
	add_child(l)
	_refresh()


func add_progress(seconds: float) -> void:
	if done:
		return
	progress += seconds * 100.0 / 15.0
	if progress >= 100.0:
		progress = 100.0
		done = true
		mat.albedo_color = Color(0.1, 0.8, 0.2)
		mat.emission = Color(0.0, 0.5, 0.1)
	_refresh()


func _refresh() -> void:
	lbl.text = "OK" if done else "%d%%" % int(progress)
